/* 
 * File:   newmain.c
 * Author: dr Vladimir Rajs
 * Opis programa: Program koji omogucava da pritiskom na taster promenimo stanje diode
*  Kori??eni taster je RD0, a dioda RB0
 * Otklonjena je mogucnost 'odskakanja tastera'.
 *
 * Created on 16. mart 2017., 11.07
 */

#include <stdio.h>
#include <stdlib.h>
#include<p30fxxxx.h>

_FOSC(CSW_FSCM_OFF & XT_PLL4);//instruction takt je isti kao i kristal
_FWDT(WDT_OFF);

typedef enum stanje{S1,S2,S3,ON,IDLE} STANJE;

int delay,taster;
STANJE st=IDLE;
STANJE nextst;
// F3 F2 F1 F0 kombinacija
int main(int argc, char** argv) {
    
    ADPCFG=0xffff;
	TRISB=0x0000;//konfigurisemo kao izlaz
	TRISF=0xffff;
    
    while(1){
    
        switch(st){
            case IDLE:
                //LATB=0x0000;
                
               	if(PORTFbits.RF3==1)
				{
                    if(delay<21)//stanje-taster mora da bude pritisnut jedno vreme
      					delay++;
				}
			    else
      				delay=0;//taster nije bio dovoljno dugo pritisnut

                if(delay==20)//ako je taster zadrzan u pritisnutom stanju jedno vreme 
     				 taster=1;//smatramo ga pritisnutim;ovim otklanjamo mogucnost 'odskakanja tastera'
        
                if(taster==1)//ukoliko je taster pritisnut menjamo stanje diode
				{            
                    taster=0;
                    nextst=S1;
                    st=nextst;
                    break;
				}else{
                    nextst=IDLE;
                    st=nextst;
                    break;
                }
                
                
            case S1:
                
                if(PORTFbits.RF2==1)
				{
                    if(delay<21)//stanje-taster mora da bude pritisnut jedno vreme
      					delay++;
				}
			    else
      				delay=0;//taster nije bio dovoljno dugo pritisnut

                if(delay==20)//ako je taster zadrzan u pritisnutom stanju jedno vreme 
     				 taster=1;//smatramo ga pritisnutim;ovim otklanjamo mogucnost 'odskakanja tastera'
        
                if(taster==1)//ukoliko je taster pritisnut menjamo stanje diode
				{
                    taster=0;
                    nextst=S2;
				}else{
                    nextst=IDLE;
                st=nextst;
                break;
                }
                
            case S2:
                if(PORTFbits.RF1==1)
				{
                    if(delay<21)//stanje-taster mora da bude pritisnut jedno vreme
      					delay++;
				}
			    else
      				delay=0;//taster nije bio dovoljno dugo pritisnut

                if(delay==20)//ako je taster zadrzan u pritisnutom stanju jedno vreme 
     				 taster=1;//smatramo ga pritisnutim;ovim otklanjamo mogucnost 'odskakanja tastera'
        
                if(taster==1)//ukoliko je taster pritisnut menjamo stanje diode
				{
                    taster=0;
                    nextst=S3;
				}else{
                    nextst=IDLE;
                st=nextst;
                break;
                }
            
            case S3:
                  if(PORTFbits.RF0==1)
				{
                    if(delay<21)//stanje-taster mora da bude pritisnut jedno vreme
      					delay++;
				}
			    else
      				delay=0;//taster nije bio dovoljno dugo pritisnut

                if(delay==20)//ako je taster zadrzan u pritisnutom stanju jedno vreme 
     				 taster=1;//smatramo ga pritisnutim;ovim otklanjamo mogucnost 'odskakanja tastera'
        
                if(taster==1)//ukoliko je taster pritisnut menjamo stanje diode
				{
                    taster=0;
                    nextst=ON;
				}else{
                    nextst=IDLE;
                st=nextst;
                break;
                }
            case ON:
                LATB=0xffff;
                break;
            default:
                st=IDLE;
                break;
                
        }
        
        
        
        
        
        
    
    
    
    }
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
	/*while(1)
		{
			if(PORTBbits.RB10==1)
				{
					if(stanje<21)//stanje-taster mora da bude pritisnut jedno vreme
      					stanje++;
				}
			else
      				stanje=0;//taster nije bio dovoljno dugo pritisnut

			if(stanje==20)//ako je taster zadrzan u pritisnutom stanju jedno vreme 
     				 taster=1;//smatramo ga pritisnutim;ovim otklanjamo mogucnost 'odskakanja tastera'
        

			if(taster==1)//ukoliko je taster pritisnut menjamo stanje diode
				{
				LATBbits.LATB7=~LATBbits.LATB7;//menjamo stanje diode
				taster=0;
				}	
		
		}//while  */

    return (EXIT_SUCCESS);
}

