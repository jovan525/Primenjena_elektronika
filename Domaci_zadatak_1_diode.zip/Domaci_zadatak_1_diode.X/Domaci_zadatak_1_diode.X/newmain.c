/* 
 * File:   newmain.c
 * Author:
 * Opis programa: 
 */

#include <stdio.h>
#include <stdlib.h>
#include<p30fxxxx.h>

_FOSC(CSW_FSCM_OFF & XT_PLL4); //podesavanje oscilatora
_FWDT(WDT_OFF); //iskljuci se watchdog tajmer


int main(int argc, char** argv) {
   
    unsigned int broj1,broj2;
    int i,a,b,c;
    int n=0;
    
    TRISB=0x0000;
    TRISC=0x0000;
    TRISD=0x0000;
    TRISA=0x0000;
    TRISF=0x0000;
    
	ADPCFG=0xffff;

	while(1)
	{
        
        //ukljucivanje
        for(i=0;i<13;i++){
            n=(1<<i);
            LATB=LATB | n;
             for(broj1=0;broj1<700;broj1++)
             for(broj2=0;broj2<300;broj2++);
             
        }
      
        for(broj1=0;broj1<700;broj1++)
        for(broj2=0;broj2<300;broj2++);
             
        for(a=0;a<7;a++){
            n=(1<<a);
            LATF=LATF | n;
            for(broj1=0;broj1<700;broj1++)
            for(broj2=0;broj2<300;broj2++);
        }
        
        LATAbits.LATA11=1;
        for(broj1=0;broj1<700;broj1++)
        for(broj2=0;broj2<300;broj2++);
        
        for(b=0;b<10;b++){
            n=(1<<b);
            LATD=LATD | n;
            for(broj1=0;broj1<700;broj1++)
            for(broj2=0;broj2<300;broj2++);
        }
        
        for(c=13;c<15;c++){
            n=(1<<c);
            LATC=LATC | n;
            for(broj1=0;broj1<700;broj1++)
            for(broj2=0;broj2<300;broj2++);
        }  
        //iskljuci mi b8 i b9, zasto?
        
        //iskljucivanje
        for(i=0;i<13;i++){
            n=(1<<i);
            LATB=LATB & (~n);
             for(broj1=0;broj1<700;broj1++)
             for(broj2=0;broj2<300;broj2++);
             
        }
        
        for(broj1=0;broj1<700;broj1++)
        for(broj2=0;broj2<300;broj2++);
             
        for(a=0;a<7;a++){
            n=(1<<a);
            LATF=LATF & (~n);
            for(broj1=0;broj1<700;broj1++)
            for(broj2=0;broj2<300;broj2++);
        }
        
        
        
        LATAbits.LATA11=0;
        for(broj1=0;broj1<700;broj1++)
        for(broj2=0;broj2<300;broj2++);
        
        for(b=0;b<10;b++){
            n=(1<<b);
            LATD=LATD & (~n);
            for(broj1=0;broj1<700;broj1++)
            for(broj2=0;broj2<300;broj2++);
        }
        
        for(c=13;c<15;c++){
            n=(1<<c);
            LATC=LATC & (~n);
            for(broj1=0;broj1<700;broj1++)
            for(broj2=0;broj2<300;broj2++);
        }  
      
         for(broj1=0;broj1<700;broj1++)
            for(broj2=0;broj2<300;broj2++);

	}// while    
    return (EXIT_SUCCESS);
}//main

